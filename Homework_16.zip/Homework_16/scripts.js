import { CommentsPage } from './comments-page.js';

const page = new CommentsPage(document.querySelector('main'));
