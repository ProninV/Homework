import './objectMethods.js';
